package com.example.testtee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
